#!/bin/bash

# Orientation Route Maker - Local Server Script
# This script starts a local server so you can access the app via http://127.0.0.1:3000

echo "🌐 Starting Orientation Route Maker Local Server..."
echo ""

# Check if node_modules exists
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies first..."
    npm install
    echo ""
fi

# Build the project
echo "🔨 Building project..."
npm run build
echo ""

# Start live-server
echo "🚀 Starting server on http://127.0.0.1:3000"
echo "📱 For mobile testing, use your computer's IP address"
echo "⏹️  Press Ctrl+C to stop the server"
echo ""

# Start live-server with specific settings
npx live-server --port=3000 --open="Orientation Route Maker.html" --no-browser
